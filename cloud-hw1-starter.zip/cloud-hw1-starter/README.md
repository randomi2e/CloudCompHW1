# Chatbot Concierge #

## About ##

Frontend starter repository for HW 1 of the Cloud Computing & Big Data
class at Columbia University and New York University.

## Usage ##

1. Clone the repository.
2. Replace `/assets/js/sdk/apigClient.js` with your own SDK file from API
   Gateway.
3. Open `chat.html` in any browser.
4. Start sending messages to test the chatbot interaction.

